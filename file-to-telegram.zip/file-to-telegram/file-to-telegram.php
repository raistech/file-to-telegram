<?php
/*
Plugin Name: File to Telegram
Description: A plugin to send files to a Telegram bot and provide a download link without storing the file on the server.
Version: 1.3
Author: Araii.ID | use [file_to_telegram_form] on your page
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue custom CSS
function ftt_enqueue_styles() {
    wp_enqueue_style('ftt-styles', plugins_url('css/style.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'ftt_enqueue_styles');

// Shortcode to display the file upload form
function ftt_file_upload_form() {
    ob_start();
    ?>
    <div class="ftt-container">
        <form method="post" action="" enctype="multipart/form-data" class="ftt-form">
            <label for="ftt_file" class="ftt-label">Select file to send (Max 2GB):</label><br>
            <input type="file" id="ftt_file" name="ftt_file" class="ftt-input" required><br><br>
            <input type="submit" name="ftt_submit" value="Send File" class="ftt-button">
        </form>
        <?php
        if (isset($_SESSION['ftt_download_link'])) {
            echo '<p class="ftt-success">File sent successfully! <a href="' . esc_url($_SESSION['ftt_download_link']) . '" target="_blank" class="ftt-download-link">Download File</a></p>';
            unset($_SESSION['ftt_download_link']);
        }
        ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('file_to_telegram_form', 'ftt_file_upload_form');

// Function to handle form submission and send file to Telegram bot
function ftt_handle_file_upload() {
    if (isset($_POST['ftt_submit']) && isset($_FILES['ftt_file'])) {
        $file = $_FILES['ftt_file'];

        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            echo '<script type="text/javascript">alert("File upload error!");</script>';
            return;
        }

        // Read the file content
        $file_name = $file['name'];

        // Send the file to Telegram bot using the Telegram API
        $telegram_token = ''; // Replace with your bot's API token
        $telegram_chat_id = ''; // Replace with your Telegram chat ID
        $telegram_url = "https://api.telegram.org/bot$telegram_token/sendDocument";

        $post_fields = array(
            'chat_id' => $telegram_chat_id,
            'document' => new CURLFile($file['tmp_name'], $file['type'], $file_name)
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "Content-Type:multipart/form-data"
        ));
        curl_setopt($ch, CURLOPT_URL, $telegram_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
        $response = curl_exec($ch);
        curl_close($ch);

        // Check the response from Telegram API
        $response_data = json_decode($response, true);
        if ($response_data['ok']) {
            $file_id = $response_data['result']['document']['file_id'];
            $file_info_url = "https://api.telegram.org/bot$telegram_token/getFile?file_id=$file_id";

            $file_info = file_get_contents($file_info_url);
            $file_info_data = json_decode($file_info, true);

            if ($file_info_data['ok']) {
                $file_path = $file_info_data['result']['file_path'];
                $download_link = "https://api.telegram.org/file/bot$telegram_token/$file_path";
                $_SESSION['ftt_download_link'] = $download_link;
            }

            echo '<script type="text/javascript">alert("File sent successfully!");</script>';
        } else {
            echo '<script type="text/javascript">alert("Failed to send file to Telegram!");</script>';
        }
    }
}
add_action('wp_head', 'ftt_handle_file_upload');

// Start the session to store download link
function ftt_start_session() {
    if (!session_id()) {
        session_start();
    }
}
add_action('init', 'ftt_start_session');